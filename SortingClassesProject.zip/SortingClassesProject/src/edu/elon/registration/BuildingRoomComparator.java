/**
* BuildingRoomComparator.java Apr 4, 2017
*
* Copyright (C) 2017 Joseph J. Staten & Eddie Staten
* Elon University, Elon, NC 27244
*/
package edu.elon.registration;


import java.util.Comparator;


/**
 * Creates a class that compares Course objects based on the name of the
 * building and the number of the room in the building using a comparator
 *
 * @author josephstaten
 * @author EdwardStaten
 *
 */
public class BuildingRoomComparator implements Comparator<Course> {
  int room = 0;
  int room2 = 0;

  @Override
  public int compare(Course aO1, Course aO2) {

    int b = aO1.getBuilding().compareTo(aO2.getBuilding());
    if (b != 0) {
      return b;
    }

    try {
      room = Integer.parseInt(aO1.getRoom());
      room2 = Integer.parseInt(aO2.getRoom());
      return Integer.compare(room, room2);

    } catch (NumberFormatException e) {
      return aO1.getRoom().compareTo(aO2.getRoom());
    }

  }
}
