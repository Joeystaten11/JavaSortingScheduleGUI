/**
* FalcutlyComparator.java Apr 4, 2017
*
* Copyright (C) 2017 Joseph J. Staten & Eddie Staten
* Elon University, Elon, NC 27244
*/
package edu.elon.registration;


import java.util.Comparator;


/**
 * Creates a class that compares Course objects based on the name of the faculty
 * using a comparator
 * 
 * @author josephstaten
 * @author Edwardstaten
 *
 */
public class FalcutlyComparator implements Comparator<Course> {
  @Override
  public int compare(Course aO1, Course aO2) {
    return (aO1.getFaculty().compareTo(aO2.getFaculty()));

  }

}