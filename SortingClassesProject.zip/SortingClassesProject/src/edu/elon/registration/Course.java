/**
* Course.java Apr 4, 2017
*
* Copyright (C) 2017 Joseph J. Staten & Edward Staten
* Elon University, Elon, NC 27244
*/
package edu.elon.registration;


/**
 * Creates a class that has a toString method and a Equals method while also
 * creating all the getters and setters for the Course objects
 *
 * @author josephstaten
 * @author josephstaten
 *
 */

public class Course {

  private String term;
  private String subj;
  private String crossList;
  private String title;

  private String faculty;
  private String building;
  private String room;
  private String startDate;
  private String dayTime;

  /**
   * creates a blank constructor
   */
  public Course() {
  }

  /**
   * creates a constructor that creates strings of the 6 varaibles
   *
   * @param sub
   * @param title
   * @param dayTime
   * @param build
   * @param room
   * @param fac
   */
  public Course(String sub, String title, String dayTime, String build,
      String room, String fac) {
    this.subj = sub;
    this.title = title;
    this.dayTime = dayTime;
    this.building = build;
    this.room = room;
    this.faculty = fac;
  }

  /**
   * overrides an equals method
   *
   */
  @Override
  public boolean equals(Object obj) {

    Course other = (Course) obj;

    if (title == null) {
      if (other.title != null) {
        return false;
      }
    } else if (!title.equals(other.title)) {
      return false;
    }
    return true;
  }

  /**
   * gets the building name
   *
   * @return the building
   */
  public String getBuilding() {
    return building;
  }

  /**
   * gets the crosslist
   *
   * @return the crossList
   */
  public String getCrossList() {
    return crossList;
  }

  /**
   * gets the day and time of the course
   *
   * @return the dayTime
   */
  public String getDayTime() {
    return dayTime;
  }

  /**
   * gets the name of the faculty
   *
   * @return the faculty
   */
  public String getFaculty() {
    return faculty;
  }

  /**
   * gets the number of the room in a string type
   *
   * @return the room
   */
  public String getRoom() {
    return room;
  }

  /**
   * gets the start date of the class in a string type
   *
   * @return the startDate
   */
  public String getStartDate() {
    return startDate;
  }

  /**
   * gets the name of the subject of the course
   *
   * @return the subj
   */
  public String getSubj() {
    return subj;
  }

  /**
   * gets the term of the course
   *
   * @return the term
   */
  public String getTerm() {
    return term;
  }

  /**
   * gets the title of the course
   *
   * @return the title
   */
  public String getTitle() {
    return title;
  }

  /**
   * sets the name of the building of the course
   *
   * @param aBuilding
   *          the building to set
   */
  public void setBuilding(String aBuilding) {
    this.building = aBuilding;
  }

  /**
   * sets the cross list
   *
   * @param aCrossList
   *          the crossList to set
   */
  public void setCrossList(String aCrossList) {
    this.crossList = aCrossList;
  }

  /**
   * sets the day and time
   *
   * @param aDayTime
   *          the dayTime to set
   */
  public void setDayTime(String aDayTime) {
    this.dayTime = aDayTime;
  }

  /**
   * sets the faculty variable
   *
   * @param aFaculty
   *          the faculty to set
   */
  public void setFaculty(String aFaculty) {
    this.faculty = aFaculty;
  }

  /**
   * sets the room number
   *
   * @param aRoom
   *          the room to set
   */
  public void setRoom(String aRoom) {
    this.room = aRoom;
  }

  /**
   * sets the start date
   *
   * @param aStartDate
   *          the startDate to set
   */
  public void setStartDate(String aStartDate) {
    this.startDate = aStartDate;
  }

  /**
   * sets teh subject name
   *
   * @param aSubj
   *          the subj to set
   */
  public void setSubj(String aSubj) {
    this.subj = aSubj;
  }

  /**
   * sets the term
   *
   * @param aTerm
   *          the term to set
   */
  public void setTerm(String aTerm) {
    this.term = aTerm;
  }

  /**
   * sets the title
   *
   * @param aTitle
   *          the title to set
   */
  public void setTitle(String aTitle) {
    this.title = aTitle;
  }

  /*
   * Overrides the to string method and creates a method to properly format our
   * display list
   *
   */

  @Override
  public String toString() {

    if (title.length() > 29) {
      title = title.substring(0, 29);
    }
    if (title.length() < 29) {
      while (title.length() < 29) {
        title += " ";
      }
    }
    if (dayTime.length() > 20) {
      dayTime = dayTime.substring(0, 20);
    }

    return "Sub:" + String.format("%-10s", subj) + " Title: "
        + String.format("%-15s", title) + "  Day/Time:"
        + String.format("%-15s", dayTime) + "  Bldg:"
        + String.format("%-5s", building) + "  Rm:"
        + String.format("%-5s", room) + "  Fac:"
        + String.format("%-1s", faculty);

  }

}