/**
* Courses.java Apr 4, 2017
*
* Copyright (C) 2017 Joseph J. Staten & Edward Staten
* Elon University, Elon, NC 27244
*/
package edu.elon.registration;


/**
 * @author josephstaten
 * @author Edwardstaten
 *
 */
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


/**
 * This class takes the file and creates all the Course objects and sorts them
 * by the desired user input
 *
 * @author josephstaten
 * @author EdwardStaten
 *
 */
public class Courses {

  private ArrayList<Course> list = new ArrayList<Course>();

  /**
   * Creates a blank constructor
   */
  public Courses() {

  }

  /**
   * Takes the criteria selected by the user and sorts the Course objects
   * accordingly
   *
   * @param aCriteria
   */
  public void getCriteria(String aCriteria) {
    if (aCriteria.equals("Building and Room")) {
      Collections.sort(list, new BuildingRoomComparator());

    }
    if (aCriteria.equals("Day and Time")) {
      Collections.sort(list, new DayTimeComparator());
    }

    if (aCriteria.equals("Faculty")) {
      Collections.sort(list, new FalcutlyComparator());
    }
    if (aCriteria.equals("Subject")) {
      Collections.sort(list, new SubjectComparator());
    }
    if (aCriteria.equals("Title")) {
      Collections.sort(list, new TitleComparator());
    }

  }

  /**
   * takes the arraylist of Course objects and transfers them to an array of
   * Course objects
   *
   * @return the new array of Course objects
   */
  public Course[] getList() {
    Course[] course3 = new Course[list.size()];
    for (int i = 0; i < list.size(); i++) {
      course3[i] = list.get(i);
    }
    return course3;

  }

  /**
   * reads the File that the user selected previously and creates new Course
   * objects holding all of the Course information
   *
   * @param selectedFile
   * @throws Exception
   */
  public void readCourses(File selectedFile) throws Exception {
    Scanner in = null;

    in = new Scanner(selectedFile);
    in.nextLine();
    while (in.hasNextLine()) {
      String line = in.nextLine();
      String[] columns = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");

      list.add(new Course(columns[1], columns[5].replaceAll("^\"|\"$", ""),
          columns[10], columns[7], columns[8], columns[6]));

    }

  }

}
