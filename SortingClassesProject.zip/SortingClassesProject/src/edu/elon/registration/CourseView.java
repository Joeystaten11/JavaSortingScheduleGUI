/**
* CourseView.java Apr 4, 2017
*
* Copyright (C) 2017 Joseph J. Staten & Eddie Staten
* Elon University, Elon, NC 27244
*/
package edu.elon.registration;


import java.awt.Font;
import java.io.File;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;


/**
 *
 * This class prompts user for inputs such as File and Criteria and displays
 * results to user
 *
 * @author josephstaten
 * @author Eddiestaten
 */
public class CourseView {

  private String box = "";
  private int loop = 1;

  /**
   * Creates an empty constructor to follow good practice
   */
  public CourseView() {

  }

  /**
   * Displays to the user all of the location names and coordinates in a table
   *
   * @param aList
   *          array of type Course
   */
  public void displayData(Course[] aList) {
    UIManager.put("OptionPane.messageFont",
        new FontUIResource(new Font("Monospaced", Font.PLAIN, 12)));
    UIManager.put("OptionPane.font",
        new FontUIResource(new Font("Monospaced", Font.PLAIN, 12)));
    UIManager.put("Label.font",
        new FontUIResource(new Font("Monospaced", Font.PLAIN, 12)));
    UIManager.put("List.font",
        new FontUIResource(new Font("Monospaced", Font.PLAIN, 12)));
    Course[] data1 = aList;

    Course display = (Course) JOptionPane.showInputDialog(null,
        "Sorted quotes by: " + box, "Elon Course selection",
        JOptionPane.INFORMATION_MESSAGE, null, data1, data1[0]);
    if (display == null) {

      System.exit(0);

    }

    loop = 0;
  }

  /**
   * Gets the Criteria which is used for sorting the data
   *
   * @return the criteria that the user selected
   */
  public String getCriteria() {

    String[] quotes = { "Building and Room", "Day and Time", "Faculty",
        "Subject", "Title" };
    box = (String) JOptionPane.showInputDialog(null,
        "Select Criteria to sort quotes by: ", "Sort Criteria",
        JOptionPane.QUESTION_MESSAGE, null, quotes, quotes[0]);

    if (box == null) {
      System.exit(0);
    }

    return box;
  }

  /**
   * gets a files from the users computer
   *
   * @return A userselected file
   * @throws IOException
   */
  public File getFile() {
    JFileChooser chooser = new JFileChooser();
    chooser.setDialogTitle("Select Course Data File");
    File selectedFile = null;
    if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
      selectedFile = chooser.getSelectedFile();
    } else {
      System.exit(0);
    }

    return selectedFile;
  }

  /**
   * this is used for the purpose of having the display criteria box be
   * reprompted after the user clicks okay in the final display. This loop value
   * is only used in the controller.
   *
   * @return loop, that is an integer
   */
  public int getLoop() {
    return loop;
  }

  /**
   * Displays the error message that is promted after an exception is cought
   *
   * @param filename
   *          as a string variable
   */
  public void showError(String filename) {
    String fileName = filename;
    String title = "Invalid File";
    JOptionPane.showMessageDialog(null,
        "The selected file " + fileName + " is not in proper format",
        title, JOptionPane.ERROR_MESSAGE);
  }

}
