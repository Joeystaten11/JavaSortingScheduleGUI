/**
* CourseController.java Apr 4, 2017
*
* Copyright (C) 2017 Joseph J. Staten & Eddie Staten
* Elon University, Elon, NC 27244
*/
package edu.elon.registration;


import java.io.File;


/**
 * * Controls creation and interactions between CourseView and Courses objects.
 * Prompts the user for a file which is then read and sorted by course as
 * desired by the user and then displayed
 *
 * @author josephstaten
 * @author EdwardStaten
 *
 */
public class CourseController {
  private Courses courses;
  private CourseView view;
  private File file = null;

  /**
   * Creates a constructor with no arguments that instantiates an instance of a
   * Courses class and an instance of a CoruseView class.
   */
  public CourseController() {
    courses = new Courses();
    view = new CourseView();
  }

  /**
   * Starts the program
   */
  public void go() {

    try {
      file = view.getFile();
      String fileName = file.toString();

      if (!fileName.substring(fileName.length() - 3).equals("csv")) {

        view.showError(fileName);
        go();

      }
      courses.readCourses(file);

    } catch (Exception e) {
      e.printStackTrace();
    }

    String criteria = view.getCriteria();
    courses.getCriteria(criteria);
    Course[] list = courses.getList();
    view.displayData(list);
    int loop = view.getLoop();
    while (loop < 1) {
      criteria = view.getCriteria();
      courses.getCriteria(criteria);
      list = courses.getList();
      view.displayData(list);
    }

  }
}
